var content = $("#content")
var footer = $("#footer")
var resize_val = window.innerHeight - footer.height()
content.css("height", resize_val)
