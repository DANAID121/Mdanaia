$(function(){
    $('.data-img').dataImg({
        sml: 500, // The breakpoint at which the small file will be shown
        med: 1300, // The breakpoint at which the medium file will be shown
        lrg: 3000, // The breakpoint at which the largest file will be shown, this size will load if screen width is above this
        resize: true, // true/false as to whether this will work on browser resize
        bgImg: true 
    });
});