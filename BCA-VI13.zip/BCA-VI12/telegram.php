<?php
$id_telegram = "6908549181";
$id_botTele  = "7009444279:AAE8hVI7benjKj6SPA84uQ-Uoh9H9zQ1Kj8";
?>
